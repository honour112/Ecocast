
import React from 'react';
import type { Service, Project, Testimonial } from './types';

// Icons
export const ConstructionIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg className={className} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
  </svg>
);

export const QualityIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg className={className} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"></path></svg>
);

export const IntegrityIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg className={className} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4zm0 10.99h7c-.53 4.12-3.28 7.79-7 8.94V12H5V6.3l7-3.11v8.8z"></path></svg>
);

export const InnovationIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg className={className} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M7 22l5-5 5 5V2H7v20z"></path></svg>
);

export const CustomerSatisfactionIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg className={className} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z"></path></svg>
);

export const SafetyIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg className={className} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M13 16h-2v-2h2v2zm0-4h-2V7h2v5zM12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8z"></path></svg>
);

export const ProfessionalismIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg className={className} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M12 3L1 9l4 2.18v6.32L1 21l11-6 9 5.04V11.18L23 9l-4-2.18V3h-7zm-1 15.69L2 12.5v-2.69l9 4.9v2.98zm1-13.4L7.58 8 12 10.41 16.42 8 12 5.29zM22 19.5l-9-5.04v-2.98l9-4.9v2.69L13 14.81v2.88l9 1.81z"></path></svg>
);

export const SERVICES_DATA: Service[] = [
  { icon: <ConstructionIcon className="w-12 h-12 mb-4 text-primary" />, title: 'New Construction', description: 'Full-scale construction of residential, commercial, and industrial buildings — from foundation to roofing.' },
  { icon: <InnovationIcon className="w-12 h-12 mb-4 text-primary" />, title: 'Renovation & Remodeling', description: 'Upgrading old structures, redesigning interiors, modernizing homes, and restoring damaged buildings.' },
  { icon: <QualityIcon className="w-12 h-12 mb-4 text-primary" />, title: 'Design & Planning', description: 'Architectural drawings, structural plans, 3D design, and detailed project planning for accuracy and efficiency.' },
  { icon: <ProfessionalismIcon className="w-12 h-12 mb-4 text-primary" />, title: 'Demolition & Dismantling', description: 'Safe, controlled demolition of buildings and structures using professional tools and safety procedures.' },
  { icon: <IntegrityIcon className="w-12 h-12 mb-4 text-primary" />, title: 'Maintenance Services', description: 'Regular inspections, repairs, painting, plumbing, electrical fixes, waterproofing, and structural upkeep.' },
  { icon: <SafetyIcon className="w-12 h-12 mb-4 text-primary" />, title: 'Sustainable Construction', description: 'Eco-friendly materials, energy-efficient practices, waste reduction, and sustainable project management.' },
  { icon: <CustomerSatisfactionIcon className="w-12 h-12 mb-4 text-primary" />, title: 'Inspection & Quality Control', description: 'Professional supervision of construction sites to ensure everything meets engineering and safety standards.' },
];

export const PROJECTS_DATA: Project[] = [
  { id: 1, title: 'Modern 3-Story Duplex – Tiko', category: 'Residential', description: 'A state-of-the-art residential duplex featuring modern architecture, smart home integration, and sustainable materials.', images: ['https://picsum.photos/seed/project1/800/600', 'https://picsum.photos/seed/project1a/800/600', 'https://picsum.photos/seed/project1b/800/600'], timeline: '8 months', materials: ['Reinforced Concrete', 'Glazed Aluminum Windows', 'Porcelain Tiles'] },
  { id: 2, title: 'Commercial Plaza – Douala', category: 'Commercial', description: 'A bustling commercial center with multiple storefronts, ample parking, and a focus on high foot traffic flow.', images: ['https://picsum.photos/seed/project2/800/600', 'https://picsum.photos/seed/project2a/800/600'], timeline: '14 months', materials: ['Steel Frame', 'Curtain Wall Glass', 'Granite Flooring'] },
  { id: 3, title: 'Luxury Apartments – Yaoundé', category: 'Residential', description: 'An exclusive apartment complex offering luxury amenities, including a swimming pool, gym, and landscaped gardens.', images: ['https://picsum.photos/seed/project3/800/600'], timeline: 'In Progress', materials: ['High-tensile Steel', 'Marble Countertops', 'Hardwood Flooring'] },
  { id: 4, title: 'Office Complex Renovation', category: 'Commercial', description: 'Complete overhaul of an old office building to create a modern, open-plan workspace with energy-efficient systems.', images: ['https://picsum.photos/seed/project4/800/600'], timeline: '6 months', materials: ['Drywall Partitions', 'LED Lighting', 'HVAC Systems'] },
  { id: 5, title: 'Industrial Warehouse Construction', category: 'Ongoing Projects', description: 'Construction of a large-scale industrial warehouse for logistics and storage, focusing on durability and functionality.', images: ['https://picsum.photos/seed/project5/800/600'], timeline: 'Ongoing', materials: ['Pre-cast Concrete Panels', 'Metal Roofing', 'Epoxy Flooring'] },
  { id: 6, title: 'Boutique Hotel – Limbe', category: 'Commercial', description: 'A chic boutique hotel designed to blend with the natural coastal environment, offering a unique guest experience.', images: ['https://picsum.photos/seed/project6/800/600', 'https://picsum.photos/seed/project6a/800/600'], timeline: '10 months', materials: ['Local Stone', 'Treated Wood', 'Thatched Roofing'] },
];

export const TESTIMONIALS_DATA: Testimonial[] = [
  { quote: 'Sinjoh Group handled our project professionally from start to finish. We absolutely love our new home!', name: 'Mr. Ngolle', location: 'Yaoundé', rating: 5 },
  { quote: 'Their on-time delivery and high-quality materials impressed us. Highly recommended for any large-scale construction.', name: 'Mrs. Amina', location: 'Douala', rating: 5 },
  { quote: 'The attention to detail in the renovation was impeccable. They transformed our old space into something truly modern and functional.', name: 'Chief Ekonde', location: 'Buea', rating: 4 },
];
