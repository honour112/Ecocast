
import React, { useState, useEffect } from 'react';

const heroImages = [
  'https://picsum.photos/seed/hero1/1920/1080',
  'https://picsum.photos/seed/hero2/1920/1080',
  'https://picsum.photos/seed/hero3/1920/1080',
];

const Hero: React.FC = () => {
  const [currentImageIndex, setCurrentImageIndex] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentImageIndex((prevIndex) => (prevIndex + 1) % heroImages.length);
    }, 5000); // Change image every 5 seconds
    return () => clearInterval(interval);
  }, []);

  const HighlightBadge: React.FC<{ children: React.ReactNode }> = ({ children }) => (
    <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-full px-4 py-2 text-sm font-medium">
      {children}
    </div>
  );

  return (
    <section id="home" className="relative h-screen flex items-center justify-center text-white overflow-hidden">
      {heroImages.map((src, index) => (
        <div
          key={src}
          className="absolute inset-0 w-full h-full bg-cover bg-center transition-opacity duration-1000"
          style={{
            backgroundImage: `url(${src})`,
            opacity: index === currentImageIndex ? 1 : 0,
            zIndex: -2,
          }}
        />
      ))}
      <div className="absolute inset-0 bg-black/60 z-[-1]"></div>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center animate-slide-in">
        <h1 className="text-4xl md:text-6xl lg:text-7xl font-slab font-extrabold text-shadow-lg leading-tight mb-4">
          Building Dreams, One Brick at a Time.
        </h1>
        <p className="text-lg md:text-xl max-w-3xl mx-auto text-gray-200 mb-8">
          Sinjoh Group International delivers world-class construction services with precision, durability, and innovation.
        </p>
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-12">
          <a href="#contact" className="bg-primary hover:bg-primary-dark text-white font-bold py-3 px-8 rounded-full transition-transform transform hover:scale-105 shadow-lg w-full sm:w-auto">
            Get a Quote
          </a>
          <a href="#services" className="bg-transparent border-2 border-primary text-primary hover:bg-primary hover:text-white font-bold py-3 px-8 rounded-full transition-all duration-300 w-full sm:w-auto">
            Our Services
          </a>
        </div>
        <div className="flex flex-wrap items-center justify-center gap-4">
          <HighlightBadge>15+ Years of Experience</HighlightBadge>
          <HighlightBadge>Certified Professionals</HighlightBadge>
          <HighlightBadge>100% Client Satisfaction</HighlightBadge>
        </div>
      </div>
    </section>
  );
};

export default Hero;
