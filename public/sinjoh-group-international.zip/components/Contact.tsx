
import React from 'react';

const Contact: React.FC = () => {
  return (
    <section id="contact" className="py-20 bg-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-slab font-bold text-secondary">Contact Us</h2>
          <p className="mt-4 text-lg text-gray-600 max-w-2xl mx-auto">
            Ready to start your next project? Get in touch with us today for a free quote.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12">
          <div className="bg-light p-8 rounded-lg shadow-lg">
            <h3 className="text-2xl font-bold text-secondary-light mb-6">Get a Quote</h3>
            <form action="#" method="POST" className="space-y-6">
              <div className="grid sm:grid-cols-2 gap-6">
                <div>
                  <label htmlFor="full-name" className="block text-sm font-medium text-gray-700">Full Name</label>
                  <input type="text" name="full-name" id="full-name" required className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary" />
                </div>
                <div>
                  <label htmlFor="phone-number" className="block text-sm font-medium text-gray-700">Phone Number</label>
                  <input type="tel" name="phone-number" id="phone-number" required className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary" />
                </div>
              </div>
              <div>
                <label htmlFor="email" className="block text-sm font-medium text-gray-700">Email Address</label>
                <input type="email" name="email" id="email" required className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary" />
              </div>
               <div className="grid sm:grid-cols-2 gap-6">
                <div>
                    <label htmlFor="project-type" className="block text-sm font-medium text-gray-700">Project Type</label>
                    <select id="project-type" name="project-type" className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-primary focus:border-primary sm:text-sm rounded-md">
                        <option>New Construction</option>
                        <option>Renovation</option>
                        <option>Design & Planning</option>
                        <option>Other</option>
                    </select>
                </div>
                <div>
                    <label htmlFor="location" className="block text-sm font-medium text-gray-700">Location</label>
                    <input type="text" name="location" id="location" className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary" />
                </div>
               </div>
              <div>
                <label htmlFor="message" className="block text-sm font-medium text-gray-700">Message</label>
                <textarea id="message" name="message" rows={4} className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary"></textarea>
              </div>
              <div>
                <label htmlFor="file-upload" className="block text-sm font-medium text-gray-700">Attach a file (optional)</label>
                 <input type="file" name="file-upload" id="file-upload" className="mt-1 block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-primary/10 file:text-primary hover:file:bg-primary/20"/>
              </div>
              <div>
                <button type="submit" className="w-full bg-primary hover:bg-primary-dark text-white font-bold py-3 px-4 rounded-md shadow-md transition-transform transform hover:scale-105">
                  Send Message
                </button>
              </div>
            </form>
          </div>
          
          <div className="space-y-8">
            <div className="bg-light p-8 rounded-lg shadow-lg">
                <h3 className="text-2xl font-bold text-secondary-light mb-4">Contact Details</h3>
                <div className="space-y-3 text-gray-600">
                    <p><strong>Phone:</strong> <a href="tel:+237652910003" className="text-primary hover:underline">+237 652 910 003</a></p>
                    <p><strong>Email:</strong> <a href="mailto:sinjohs@yahoo.com" className="text-primary hover:underline">sinjohs@yahoo.com</a></p>
                    <p><strong>Location:</strong> Tiko – Street 4, Cameroon</p>
                </div>
            </div>
            <div className="rounded-lg shadow-lg overflow-hidden h-80">
                <iframe 
                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d15917.89241831818!2d9.35246755!3d4.084124999999999!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x1060c41b4f4f7f6d%3A0x8f3c75f56c8c4e0!2sTiko%2C%20Cameroon!5e0!3m2!1sen!2sus!4v1678886543210!5m2!1sen!2sus" 
                    width="100%" 
                    height="100%" 
                    style={{border:0}} 
                    allowFullScreen={true}
                    loading="lazy" 
                    referrerPolicy="no-referrer-when-downgrade"
                    title="Company Location"
                ></iframe>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;
