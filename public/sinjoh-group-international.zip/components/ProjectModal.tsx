
import React from 'react';
import type { Project } from '../types';

interface ProjectModalProps {
  project: Project;
  onClose: () => void;
}

const ProjectModal: React.FC<ProjectModalProps> = ({ project, onClose }) => {
  return (
    <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-[100] p-4 animate-slide-in" onClick={onClose}>
      <div
        className="bg-white rounded-lg shadow-2xl w-full max-w-4xl max-h-[90vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="relative">
            <img src={project.images[0]} alt={project.title} className="w-full h-64 md:h-96 object-cover rounded-t-lg" />
            <button
                onClick={onClose}
                className="absolute top-4 right-4 bg-white/70 text-secondary rounded-full p-2 hover:bg-white transition-all"
            >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
            </button>
        </div>
        
        <div className="p-8">
            <span className="text-sm bg-primary/20 text-primary-dark font-semibold px-3 py-1 rounded-full">{project.category}</span>
            <h2 className="text-3xl font-bold text-secondary my-3">{project.title}</h2>
            <p className="text-gray-600 mb-6">{project.description}</p>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                <div>
                    <h4 className="font-bold text-secondary-light mb-2">Project Timeline</h4>
                    <p className="text-gray-600">{project.timeline}</p>
                </div>
                <div>
                    <h4 className="font-bold text-secondary-light mb-2">Key Materials</h4>
                    <ul className="list-disc list-inside text-gray-600">
                        {project.materials.map((material, index) => (
                            <li key={index}>{material}</li>
                        ))}
                    </ul>
                </div>
            </div>
            
            <h4 className="font-bold text-secondary-light mb-4">Gallery</h4>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                {project.images.map((img, index) => (
                    <img key={index} src={img} alt={`${project.title} - view ${index + 1}`} className="w-full h-32 object-cover rounded-lg shadow-md" />
                ))}
            </div>
        </div>
      </div>
    </div>
  );
};

export default ProjectModal;
