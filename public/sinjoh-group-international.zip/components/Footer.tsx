
import React from 'react';

const Footer: React.FC = () => {
    const socialLinks = [
        { name: 'WhatsApp', href: 'https://wa.me/237652910003', icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" viewBox="0 0 24 24" fill="currentColor"><path d="M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946.003-6.556 5.338-11.891 11.893-11.891 3.181.001 6.167 1.24 8.413 3.488 2.245 2.248 3.481 5.236 3.48 8.414-.003 6.557-5.338 11.892-11.894 11.892-1.99-.001-3.951-.5-5.688-1.448l-6.305 1.654zm6.597-3.807c1.676.995 3.276 1.591 5.392 1.592 5.448 0 9.886-4.434 9.889-9.885.002-5.462-4.415-9.89-9.881-9.892-5.452 0-9.887 4.434-9.889 9.886-.001 2.267.655 4.398 1.908 6.161l-.219.341-1.018 3.731 3.75-1.001.334-.232z"/></svg> },
        { name: 'Email', href: 'mailto:sinjohs@yahoo.com', icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" viewBox="0 0 24 24" fill="currentColor"><path d="M20 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z"/></svg> },
        { name: 'Facebook', href: '#', icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" viewBox="0 0 24 24" fill="currentColor"><path d="M5 3h14a2 2 0 012 2v14a2 2 0 01-2 2H5a2 2 0 01-2-2V5a2 2 0 012-2m13 2h-2.5a3.5 3.5 0 00-3.5 3.5V11h-2v3h2v7h3v-7h3v-3h-3V8.5A.5.5 0 0115 8h3V5z"/></svg> },
    ];

  return (
    <footer className="bg-secondary text-gray-300">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          
          <div>
            <h3 className="text-xl font-slab font-bold text-primary mb-4">Sinjoh Group Int'l</h3>
            <p className="text-sm">Building dreams with precision, durability, and innovation across Cameroon.</p>
          </div>
          
          <div>
            <h4 className="font-semibold text-white mb-4">Quick Links</h4>
            <ul className="space-y-2 text-sm">
              <li><a href="#home" className="hover:text-primary transition">Home</a></li>
              <li><a href="#about" className="hover:text-primary transition">About</a></li>
              <li><a href="#services" className="hover:text-primary transition">Services</a></li>
              <li><a href="#projects" className="hover:text-primary transition">Projects</a></li>
              <li><a href="#contact" className="hover:text-primary transition">Contact</a></li>
            </ul>
          </div>

          <div>
            <h4 className="font-semibold text-white mb-4">Contact Info</h4>
            <address className="not-italic space-y-2 text-sm">
              <p>Tiko – Street 4, Cameroon</p>
              <p>
                <a href="tel:+237652910003" className="hover:text-primary transition">+237 652 910 003</a>
              </p>
              <p>
                <a href="mailto:sinjohs@yahoo.com" className="hover:text-primary transition">sinjohs@yahoo.com</a>
              </p>
            </address>
          </div>

          <div>
            <h4 className="font-semibold text-white mb-4">Follow Us</h4>
            <div className="flex space-x-4">
                {socialLinks.map(link => (
                    <a key={link.name} href={link.href} target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-primary transition">
                        {link.icon}
                    </a>
                ))}
            </div>
          </div>

        </div>
      </div>
      <div className="bg-secondary-light py-4">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center text-sm text-gray-400">
            © {new Date().getFullYear()} Sinjoh Group International — All Rights Reserved.
        </div>
      </div>
    </footer>
  );
};

export default Footer;
