
import React from 'react';
import { QualityIcon, IntegrityIcon, InnovationIcon, CustomerSatisfactionIcon, SafetyIcon, ProfessionalismIcon } from '../constants';

const About: React.FC = () => {

  const coreValues = [
    { icon: <QualityIcon className="w-10 h-10 mx-auto text-primary" />, title: "Quality" },
    { icon: <IntegrityIcon className="w-10 h-10 mx-auto text-primary" />, title: "Integrity" },
    { icon: <InnovationIcon className="w-10 h-10 mx-auto text-primary" />, title: "Innovation" },
    { icon: <CustomerSatisfactionIcon className="w-10 h-10 mx-auto text-primary" />, title: "Customer Satisfaction" },
    { icon: <SafetyIcon className="w-10 h-10 mx-auto text-primary" />, title: "Safety First" },
    { icon: <ProfessionalismIcon className="w-10 h-10 mx-auto text-primary" />, title: "Professionalism" },
  ];

  const whyChooseUs = [
    "Expert Craftsmanship", "Years of Experience", "On-Time Completion",
    "Competitive Pricing", "High-Quality Materials", "Safety First",
    "Client Satisfaction", "Innovative Solutions"
  ];

  const SectionTitle: React.FC<{ children: React.ReactNode }> = ({ children }) => (
    <h2 className="text-3xl md:text-4xl font-slab font-bold text-secondary mb-8 text-center">{children}</h2>
  );

  return (
    <section id="about" className="py-20 bg-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <SectionTitle>About Sinjoh Group International</SectionTitle>
        
        <div className="max-w-4xl mx-auto text-center text-lg text-gray-600 mb-16">
          <p>Sinjoh Group International is a professional construction and engineering company delivering top-tier building solutions across Cameroon. Our focus is quality, safety, innovation, and timely project delivery.</p>
        </div>

        <div className="grid md:grid-cols-2 gap-12 mb-16 items-center">
            <div className="space-y-6">
                <div>
                    <h3 className="text-2xl font-bold text-secondary-light mb-2">Our Mission</h3>
                    <p className="text-gray-600">To build strong, durable, and visually appealing structures that meet global construction standards.</p>
                </div>
                <div>
                    <h3 className="text-2xl font-bold text-secondary-light mb-2">Our Vision</h3>
                    <p className="text-gray-600">To become the leading construction company in Central Africa — known for reliability, innovation, and excellence.</p>
                </div>
            </div>
            <div>
              <img src="https://picsum.photos/seed/aboutus/600/400" alt="Construction team planning" className="rounded-lg shadow-xl"/>
            </div>
        </div>

        <div className="mb-16">
          <h3 className="text-2xl font-bold text-secondary-light mb-8 text-center">Our Core Values</h3>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-8 text-center">
            {coreValues.map((value, index) => (
              <div key={index} className="p-4 bg-light rounded-lg shadow-md transition-transform transform hover:-translate-y-2">
                {value.icon}
                <p className="mt-2 font-semibold text-secondary">{value.title}</p>
              </div>
            ))}
          </div>
        </div>

        <div>
            <h3 className="text-2xl font-bold text-secondary-light mb-8 text-center">Why Choose Us?</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                {whyChooseUs.map((item, index) => (
                    <div key={index} className="flex items-center p-4 bg-light rounded-lg shadow-sm">
                        <svg className="w-6 h-6 text-accent mr-3 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path></svg>
                        <span className="font-medium text-secondary">{item}</span>
                    </div>
                ))}
            </div>
        </div>

      </div>
    </section>
  );
};

export default About;
