
import React, { useState, useMemo } from 'react';
import { PROJECTS_DATA } from '../constants';
import type { Project } from '../types';

interface ProjectsProps {
  onProjectClick: (project: Project) => void;
}

const Projects: React.FC<ProjectsProps> = ({ onProjectClick }) => {
  const [activeFilter, setActiveFilter] = useState('All');
  const filters = ['All', 'Residential', 'Commercial', 'Ongoing Projects'];

  const filteredProjects = useMemo(() => {
    if (activeFilter === 'All') {
      return PROJECTS_DATA;
    }
    return PROJECTS_DATA.filter(project => project.category === activeFilter);
  }, [activeFilter]);

  const FilterButton: React.FC<{ label: string }> = ({ label }) => (
    <button
      onClick={() => setActiveFilter(label)}
      className={`px-6 py-2 rounded-full font-medium transition-all duration-300 ${activeFilter === label ? 'bg-primary text-white shadow-md' : 'bg-white text-secondary hover:bg-primary/10'}`}
    >
      {label}
    </button>
  );

  return (
    <section id="projects" className="py-20 bg-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-slab font-bold text-secondary">Our Projects</h2>
          <p className="mt-4 text-lg text-gray-600 max-w-2xl mx-auto">
            A showcase of our commitment to quality, craftsmanship, and innovation.
          </p>
        </div>

        <div className="flex justify-center flex-wrap gap-4 mb-12">
          {filters.map(filter => <FilterButton key={filter} label={filter} />)}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredProjects.map((project, index) => (
            <div
              key={project.id}
              className="group relative overflow-hidden rounded-lg shadow-lg cursor-pointer"
              onClick={() => onProjectClick(project)}
              style={{ animation: 'slide-in 0.5s ease-out forwards', animationDelay: `${index * 100}ms`, opacity: 0 }}
            >
              <img
                src={project.images[0]}
                alt={project.title}
                className="w-full h-72 object-cover transition-transform duration-500 group-hover:scale-110"
                loading="lazy"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent"></div>
              <div className="absolute bottom-0 left-0 p-6 text-white">
                <span className="text-sm bg-primary/80 px-2 py-1 rounded">{project.category}</span>
                <h3 className="text-xl font-bold mt-2">{project.title}</h3>
                <div className="opacity-0 group-hover:opacity-100 transition-opacity duration-300 mt-2 text-sm">
                  <p>Click to view details &rarr;</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Projects;
